/*		pic.c

		Routines for the 8259 PIC

	History:

		Version 0.01.00	18 May 2000	15:13		ObliVion
		Initial version.
*/
#include <stdio.h>
#include <i386/pic.h>
#include <i386/ports.h>

int init_pic(void)
{
	return(0);
}

void unmask_irq(unsigned short irq_no)
{
}

void mask_irq(unsigned short irq_no)
{
}
