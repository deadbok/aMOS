/*		mailbox.c

		The mailbox code for comunication with (and within) the micro-kernel

	History:

		Version 0.01.01	10 Sep 2000	13:15		ObliVion
		Initial version.
*/

#include <stdio.h>
#include <string.h>
#include <i386/setup.h>
#include <kernel/mailbox.h>

struct mailbox *get_mb(char *name);

static struct mailbox	*mb_head = NULL;
static struct mailbox	*mb_tail = NULL;

int create_mb(struct mailbox *mb)
{
	mb->msg_head = NULL;
	mb->msg_tail = NULL;
	mb->rcv_head = NULL;
	mb->rcv_tail = NULL;

	if (mb_head)
		mb_tail->next=mb;
	else
		mb_head=mb;
		
	mb_tail=mb;
		
	if ((mb_head) && (mb_tail))
		return(0);
	else
		return(1);
}

struct mailbox *get_mb(char *name)
{
	struct mailbox	*mb = mb_head;

	if (!mb)
		return(NULL);
				
	while (mb)
	{
		if (!strcmp(mb->name, name))
			return(mb);
		mb=mb->next;
	}

	return(NULL);
}

int send(char *name, struct message *msg)
{
	struct mailbox	*mb;
	struct message	*temp_msg;

	if (!msg)
		return(1);

	msg->next=NULL;
				
	mb=get_mb(name);
		
	if (!mb)
		return(1);

	if (mb->msg_head)
	{
		temp_msg=mb->msg_head;
				
		while(temp_msg)
			if (temp_msg!=msg)
				temp_msg=temp_msg->next;
			else
				return(1);
			
		mb->msg_tail->next=msg;
	}
	else
		mb->msg_head=msg;
	
	mb->msg_tail=msg;
		
	if ((mb->msg_head) && (mb->msg_tail))
		return(0);
	else
		return(1);
				
	return(0);
}

int recieve(char *name, struct reciever *rcv)
{
	struct mailbox	*mb;
	struct reciever	*temp_rcv;
		
	if (!rcv)
		return(1);
	
	rcv->next=NULL;
		
	mb=get_mb(name);
		
	if (!mb)
		return(1);
						
	if (mb->rcv_head)
	{
		temp_rcv=mb->rcv_head;
				
		while(temp_rcv)
			if (temp_rcv!=rcv)
				temp_rcv=temp_rcv->next;
			else
				return(1);
			
		mb->rcv_tail->next=rcv;
	}
	else
		mb->rcv_head=rcv;
	
	mb->rcv_tail=rcv;
		
	if ((mb->rcv_head) && (mb->rcv_tail))
		return(0);
	else
		return(1);
	
	return(0);
}

int message_dispatch(void)
{
	struct mailbox	*mb = mb_head;
		
	while (mb)
	{
		while ((mb->msg_head) && (mb->rcv_head))
		{
			(*mb->rcv_head->rcv)(mb->msg_head);

			switch(mb->rcv_head->mode)
			{
				case	RCV_ONE_TIME:	mb->msg_head=mb->msg_head->next;
										mb->rcv_head=mb->rcv_head->next;
										break;

				case	RCV_CONTINUOS:	mb->msg_head=mb->msg_head->next;
										
										if (mb->rcv_head->next)
										{
											mb->rcv_tail->next=mb->rcv_head;
											mb->rcv_tail=mb->rcv_head;
											mb->rcv_head=mb->rcv_head->next;
											mb->rcv_tail->next=NULL;
										}
										break;

				default:				return(1);
			}
			if (!mb->msg_head)
				mb->msg_tail=NULL;
			if (!mb->rcv_head)
				mb->rcv_tail=NULL;
		}
		mb=mb->next;
	}

	return(0);
}