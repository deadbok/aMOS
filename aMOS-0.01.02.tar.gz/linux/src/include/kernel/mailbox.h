/*		mailbox.h

		The mailbox code for comunication with (and within) the micro-kernel

	History:

		Version 0.01	17 May 2000	17:45		ObliVion
		Initial version.
*/
#include <stddef.h>
#include <kernel/task.h>

#ifndef _MAILBOX_H_
#define _MAILBOX_H_

struct message;

typedef	void	(*rcv_func_t)(struct message *msg);

#define	RCV_ONE_TIME	1
#define RCV_CONTINUOS	2

struct message
{
	struct message	*next;
	unsigned short	type;
	size_t			data_size;
	void			*data;
};

struct reciever
{
	struct reciever	*next;
	rcv_func_t		rcv;
	char			mode;
};

struct mailbox
{
	char			*name;
	struct message	*msg_head;
	struct message	*msg_tail;
	struct reciever	*rcv_head;
	struct reciever	*rcv_tail;
	struct mailbox	*next;
};

extern int create_mb(struct mailbox *mb);
extern int send(char *name, struct message *msg);
extern int recieve(char *name, struct reciever *rcv);
extern int message_dispatch(void);

#endif