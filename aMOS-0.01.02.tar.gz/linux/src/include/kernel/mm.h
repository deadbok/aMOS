/*		mm.h

		Header file for the Memory Manager

	History:
		Version 0.02.01	08 Oct 2000		19:09		ObliVion
		Simplified the whole damn thing, as this only used by the kernel.

		Version 0.01.01	03 July 2000	22:22		ObliVion
		Initial version.
*/
#ifndef KERNEL_MM_H
#define KERNEL_MM_H

struct mem_block_node
{
	struct mem_block_node	*prev, *next;
	void					*mem;
	unsigned long			size;
	unsigned char			free;
} __attribute__ ((packed));

extern int 					init_mm(void);
extern void 				*alloc_block(unsigned long size);
extern int 					dealloc_block(void *addr);
extern unsigned long 		get_free_mem(void);
extern unsigned long 		get_used_mem(void);

#endif
