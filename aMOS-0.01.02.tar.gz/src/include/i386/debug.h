/*		debug.h

		Debugging functions for the kernel

	History:
		Version 0.01.02	29 April 2001	01:07		ObliVion
		Initial version.
*/

#ifndef _DEBUG_H_
#define _DEBUG_H_

#ifdef DEBUG
#include <stdarg.h>

extern int debug_printf(const char *format,...);
extern void debug_halt(void);
#endif

#endif

