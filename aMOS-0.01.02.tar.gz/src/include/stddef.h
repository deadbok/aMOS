/*		stddef.h

		Standard defines C Header for libc

	History:

		Version 0.01	02 July 2000	17:00		ObliVion
		Initial version.
*/

#ifndef __STDDEF_H_
#define __STDDEF_H

#include <types.h>

#endif
