/*		module.h

		The header for the dynamic module loader

	History:

		Version 0.01.00	04 Okt 2000	09:05		ObliVion
		Initial version.
*/
#include <stddef.h>

#ifndef _MODULE_H_
#define _MODULE_H_

struct module_info
{
	struct module_info	*next;
	size_t			size;
	void			*entry;
};

#endif
