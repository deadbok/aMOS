/*		list.h

		Include file for the aMOS mikro-kernel linked list
		implementation

	History:
		Version 0.01.01	07 Apr 2001	19:55		ObliVion
		Initial version.
*/

#ifndef _LIST_H_
#define _LIST_H_

/*#define	DEBUG*/

#define	LIST_OK				0
#define LIST_EMPTY_NODE		1

struct list_node
{
	void	*data;
	void	*next;
};

extern	struct list_node	*new_node(void);
extern	int 				add_node(struct list_node *root, struct list_node *new_node);
extern	int					destroy_list(struct list_node *root);

#endif
