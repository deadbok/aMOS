/*		video.h

		The video output function used by the loader and the micro-kernel

	History:

		Version 0.01.01	08 Sep 	2000	18:30		ObliVion
		Initial version.
*/
#include <kernel/mailbox.h>

#ifndef _KERNEL_VIDEO_H
#define _KERNEL_VIDEO_H

#define VMSG_CHAR		1
#define VMSG_STRING		2
#define VMSG_FCOLOR		3
#define VMSG_BCOLOR		4

#define BLACK			0x00
#define BLUE			0x01
#define GREEN			0x02
#define CYAN			0x03
#define RED				0x04
#define MAGENTA			0x05
#define BROWN			0x06
#define WHITE			0x07
#define GRAY			0x08
#define LIGHT_BLUE		0x09
#define LIGHT_GREEN		0x0a
#define	LIGHT_CYAN		0x0b
#define	LIGHT_RED		0x0c
#define	LIGHT_MAGENTA	0x0d
#define LIGHT_BROWN		0x0e
#define YELLOW			0x0e
#define BRIGHT_WHITE	0x0f

extern mailbox_id_type	video_mailbox;

#endif
