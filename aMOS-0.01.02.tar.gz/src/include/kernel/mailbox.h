/*		mailbox.h

		The mailbox code for comunication with (and within) the micro-kernel

	History:

		Version 0.01	17 May 2000	17:45		ObliVion
		Initial version.
*/
#include <stddef.h>
#include <kernel/list.h>
#include <kernel/task.h>

#ifndef _MAILBOX_H_
#define _MAILBOX_H_

/*#define	DEBUG*/
#undef	DEBUG

#define	MAILBOX_CANT_ADD		0
#define	MAILBOX_OK				1
#define MAILBOX_EMPTY_MESSAGE	2
#define MAILBOX_DONT_EXIST		3

struct msg;

typedef unsigned short	mailbox_id_type;
typedef	void			(*rcv_func_t)(struct msg *message);

struct msg
{
	unsigned char	type;
	size_t			data_size;
	void			*data;
};

struct mailbox
{
	mailbox_id_type		id;
	struct list_node	*messages;
	rcv_func_t			reciever;
};

extern mailbox_id_type create_mb(rcv_func_t reciever);
extern int send(mailbox_id_type id, struct msg *message);
extern int message_dispatch(void);

#endif

