/*		pit.c

		Routines for the 8253/54 PIT

	History:

		Version 0.01	18 May 2000	15:13		ObliVion
		Initial version.
*/
#include <stdio.h>
#include <i386/pit.h>
#include <i386/ports.h>

int init_pit(void)
{
/*	printf("Starting timer...\n");*/

	outb(PIT_MODE, CNT_LMSB+CNT_MODE_3);
	
	outb(PIT_CNT_0, (1193180/1) & 0xff);
	outb(PIT_CNT_0, (1193180/1) >> 8);

	return(0);
}
