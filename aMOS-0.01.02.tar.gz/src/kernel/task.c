/*		task.c

		Task management code

	History:

		Version 0.01.01	10 Sep 2000	17:03		ObliVion
		Initial version.
*/

#include <kernel/task.h>

	