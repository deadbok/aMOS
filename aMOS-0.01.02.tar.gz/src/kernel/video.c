/*		video.c

		The video output function used by the loader and the micro-kernel

	History:

		Version 0.01.01	08 Sep 	2000	18:30		ObliVion
		Initial version.
*/
#include <kernel/video.h>
#include <kernel/mailbox.h>

static struct mailbox	mb_video = {"video", NULL, NULL, NULL, NULL, NULL};

int init_video_mb(void)
{
	return(create_mb(&mb_video));
}