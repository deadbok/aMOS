/*        strcpy.c

          strcpy function for libc

     History:

          Version 0.01.01   24 April 2001   01:48          ObliVion
          Initial version.

*/
#include <string.h>

char *strcpy(char *dest, const char *src)
{
	char		*d = dest;
	char		*s = src;	
     
	while(s!='\0')
		*d++=*s++;
	
	*d='\0';

	return(dest);
}
