/*		main.c

		The main C code for the aMOS kernel

	History:
		Version 0.01.10	10 Sep 2000	14:07		ObliVion
		Initial version.

		Version 0.01.01	17 May 2000	17:45		ObliVion
		Initial version.
*/

/*
	They keep showing this comercial on the telly
	"this dream feels like ours"
	It's one of those comercials that depends on "harmony"
	The mood is wonderfully expressed
	But the point is...
	There is this girl
	And there is this 1 second shot of her face
	As she wakes up her boyfriend
	She has the most beautiful expression in her face
	I've never seen anything quite as beautiful
	In a comercial
	And all it does my dear sunflower
	Is push the knife in a little bit more
	'Cos you were that beautiful most of the time
	That's one of the reasons I still love you
	When you've seen what you think is perfection
	You don't just let it slip away
*/

#include <stddef.h>
#include <stdio.h>
#include <i386/setup.h>
#include <kernel/task.h>
#include <kernel/mailbox.h>

void rcv1(struct message *msg);
void rcv2(struct message *msg);

struct mailbox	mb1 = {"mb1", NULL, NULL, NULL, NULL, NULL};
struct tcb		tcb1 = {NULL, (void *)rcv1, 0};
struct tcb		tcb2 = {NULL, (void *)rcv2, 1};

void rcv1(struct message *msg)
{
	printf("Receiver 1 got a message\n");
}

void rcv2(struct message *msg)
{
	printf("Receiver 2 got a message\n");
}

int main(void) 
{
	arch_setup();
/*	if (create_mb(&mb1))
	{
		printf("Failed creating mailbox mb1\n");
		return(1);
	}
	
	printf("Mailbox mb1 created\n");
					
	if (send("mb1", NULL))
	{
		printf("Failed sending messsage to mb1\n");
		return(1);
	}		

	printf("Message send to mb1\n");*/
		
	return(0);
}
