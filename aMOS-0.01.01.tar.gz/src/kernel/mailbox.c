/*		mailbox.c

		The mailbox code for comunication with (and within) the micro-kernel

	History:

		Version 0.01.01	10 Sep 2000	13:15		ObliVion
		Initial version.
*/

#include <string.h>
#include <kernel/mailbox.h>

struct mailbox *get_mb(char *name);

static struct mailbox	*mb_head = NULL;
static struct mailbox	*mb_tail = NULL;

int create_mb(struct mailbox *mb)
{
	mb->msg_head = NULL;
	mb->msg_tail = NULL;
	mb->rcv_head = NULL;
	mb->rcv_tail = NULL;

	if (mb_head)
		mb_tail->next=mb;
	else
		mb_head=mb;
		
	mb_tail=mb;
		
	if ((mb_head) && (mb_tail))
		return(0);
	else
		return(1);
}

struct mailbox *get_mb(char *name)
{
	struct mailbox	*mb;

	if ((!mb_head) || (!mb_tail))
		return(NULL);

	for (mb=mb_head; mb->next; mb=mb->next)
		if (!strcmp(mb->name, name))
			return(mb);

	return(NULL);
}

int send(char *name, struct message *msg)
{
	struct mailbox	*mb;
		
	mb=get_mb(name);
		
	if (!mb)
		return(0);
	return(0);
}

int receive(char *name, struct tcb *rcv_tcb)
{
	struct mailbox	*mb;
	struct tcb		*new_tcb = NULL;
		
	mb=get_mb(name);
		
	if (!mb)
		return(0);
						
	if (mb->msg_head)
	{
		new_tcb=mb->rcv_head;
		
		mb->msg_head=mb->msg_head->next;
						
		if (!mb->msg_head)
			mb->msg_tail=NULL;
	}
	else
	{
		if (mb->rcv_head)
			mb->rcv_tail->next=rcv_tcb;
		else
			mb->rcv_head=rcv_tcb;
		
		mb->rcv_tail=rcv_tcb;
	}
	
	return(0);
}