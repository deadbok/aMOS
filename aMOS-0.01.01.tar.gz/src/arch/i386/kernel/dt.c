/*		dt.c

		General Descriptor Table functions

	History:

		Version 0.01	11 Sep 2000	19:50		ObliVion
		Initial version.
*/
