/*		setup.c

		Architecture setup

	History:

		Version 0.01.00	16 Sep 2000	23:10		ObliVion
		Initial version.
*/
#include <i386/setup.h>

struct kernel_param	kernel_parameters;
putch_func			putch;

int	arch_setup(void)
{
	putch=(putch_func)kernel_parameters.putch;
		
	(*putch)('O');
		
	return(0);
}
