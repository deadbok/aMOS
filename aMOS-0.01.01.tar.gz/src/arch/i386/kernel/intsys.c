/*		intsys.c

		The interrupt sub-system of the kernel (nothing cool yet)

	History:

		Version 0.01.00	01 july 2000	21:18		ObliVion
		Initial version.
*/
#include <string.h>
#include <i386/setup.h>
#include <i386/intsys.h>
#include <i386/halt.h>

unsigned long		intlist[MAX_INTS];

int init_intr(void)
{
	unsigned int	i;
	for (i=0; i<MAX_INTS; i++)
		intlist[i]=(unsigned long)handle_int;

/*	memset(intlist, handle_int, MAX_INTS);*/

	int_enable();

	return(0);
}

void handle_int(int intr)
{
	char		*ptr = (char *)0xb8000;
		
	*ptr++=0x40;
	*ptr=0x40;
}

void install_isr(int intr, unsigned long isr)
{
	if (intr<MAX_INTS)
	{
		intlist[intr]=isr;
	}
}