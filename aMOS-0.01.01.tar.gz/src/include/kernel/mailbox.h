/*		mailbox.h

		The mailbox code for comunication with (and within) the micro-kernel

	History:

		Version 0.01	17 May 2000	17:45		ObliVion
		Initial version.
*/
#include <stddef.h>
#include <kernel/task.h>

#ifndef _MAILBOX_H_
#define _MAILBOX_H_

struct message
{
	struct message	*next;
	unsigned short	type;
	size_t			data_size;
	void			*data;
};

struct mailbox
{
	char			*name;
	struct message	*msg_head;
	struct message	*msg_tail;
	struct tcb		*rcv_head;
	struct tcb		*rcv_tail;
	struct mailbox	*next;
};

typedef	void	(*rcv_func)(struct message *msg);

extern int create_mb(struct mailbox *mb);
extern int send(char *name, struct message *msg);
extern int receive(char *name, struct tcb *rcv_pcb);

#endif