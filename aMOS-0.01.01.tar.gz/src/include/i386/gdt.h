/*		gdt.h

		The GDT stuff

	History:

		Version 0.01	27 june 2000	12:35		ObliVion
		Initial version.
*/
#ifndef _KERNEL_GDT_H_
#define _KERNEL_GDT_H_

#include <i386/selector.h>

#define K_TSS				0x4000

__inline__ void lgdt(struct dt_ptr *pdt);

struct x86_tss
{
    unsigned long			back;
    unsigned long			esp0;
    unsigned long			ss0;
    unsigned long			esp1;
    unsigned long			ss1;
    unsigned long			esp2;
    unsigned long			ss2;
    unsigned long			cr3;
    unsigned long			eip;
    unsigned long			eflags;
    unsigned long			eax;
    unsigned long			ecx;
    unsigned long			edx;
    unsigned long			ebx;
    unsigned long			esp;
    unsigned long			ebp;
    unsigned long			esi;
    unsigned long			edi;
    unsigned long			es;
    unsigned long			cs;
    unsigned long			ss;
    unsigned long			ds;
    unsigned long			fs;
    unsigned long			gs;
    unsigned long			ldt;
    unsigned long			ioperm;
} __attribute__((packed));

extern	void init_gdt(void);

#endif /* _KERNEL_GDT_H_ */