/*		intsys.c

		The interrupt sub-system of the kernel (nothing cool yet)

	History:
		Version 0.01.01	06 Oct	2000	00:37		ObliVion
		Got it to work!

		Version 0.01.00	01 july 2000	21:18		ObliVion
		Initial version.
*/
#include <string.h>
#include <stdio.h>
#include <i386/setup.h>
#include <i386/intsys.h>
#include <i386/ports.h>
#include <i386/pic.h>

int init_intr(void)
{
	printf("Initializing interrupt system...\n");

	return(0);
}

void handle_int(unsigned long intr)
{
}

void install_isr(int intr, isr_func_t isr)
{
}