/*		video.c

		The video output function used by the loader and the micro-kernel

	History:

		Version 0.01.01	12 Sep 	2000	17:26		ObliVion
		Initial version.
*/
#include <stdio.h>
#include <i386/video.h>
#include <kernel/video.h>

void 			vid_rcv_func(struct message *msg);

struct reciever	rcv = {NULL, vid_rcv_func, RCV_CONTINUOS};

int vid_init(void)
{
	if (recieve("video", &rcv))
		return(1);

	return(0);
}

void vid_rcv_func(struct message *msg)
{
	unsigned long		i;
	switch(msg->type)
	{
		case	VMSG_CHAR:		vid_putch(*((char *)msg->data));
								vid_putch('C');
								break;
		
		case	VMSG_STRING:	for (i=0; i<msg->data_size; i++)
									vid_putch(*((char *)msg->data+i));
								vid_putch('S');
								break;																		
									
		default:		return;
	}
}

void vid_putch(char ch)
{
	printf("%c", ch);
}

