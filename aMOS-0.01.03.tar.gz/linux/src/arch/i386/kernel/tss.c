/*		tss.c

		The TSS stuff

	History:

		Version 0.01.00	06 Oct 2000	04:37		ObliVion
		Initial version.
*/
#include <string.h>
#include <stdio.h>
#include <i386/dt.h>
#include <i386/tss.h>
#include <i386/setup.h>
#include <i386/selector.h>

void ltr(unsigned short selector);

void init_tss(void)
{
	printf("Initializing hardware task switching...\n");
}

void ltr(unsigned short selector)
{
}

