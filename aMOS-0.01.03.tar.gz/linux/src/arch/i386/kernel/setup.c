/*		setup.c

		Architecture setup

	History:
		Version 0.01.01	06 Oct	2000	00:39		ObliVion
		Added function to install the schedulter interrupt.

		Version 0.01.00	16 Sep	2000	23:10		ObliVion
		Initial version.
*/
#define ARCH_FILE 1

#include <stddef.h>
#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/signal.h>
#include <i386/setup.h>
#include <i386/video.h>
#include <i386/pic.h>
#include <i386/pit.h>
#include <i386/tss.h>
#include <i386/ports.h>
#include <i386/intsys.h>
#include <kernel/version.h>

int	arch_setup(void)
{
	vid_init();
		
	printf("\n\naMOS V.%s %s\n", STRING_VERSION, BUILD_ARCH);
	printf("Build %s %s by %s on %s\n\n", COMPILE_DATE, COMPILE_TIME, COMPILE_BY, COMPILE_HOST);
	
	printf("---------- arch_setup ----------\n");
	init_pic();
	init_intr();

	init_pit();
		
	int_enable();

	init_tss();

	return(0);
}

int install_sched_func(void *func)
{
	struct itimerval	timer;

	if (signal(SIGALRM, func)==SIG_ERR)
	{
		printf("Error setting handler\n");
	}

	timer.it_interval.tv_sec=0;
	timer.it_interval.tv_usec=50;
	timer.it_value.tv_sec=0;
	timer.it_value.tv_usec=100;
	setitimer(ITIMER_REAL, &timer, NULL);
	
	return(0);
}

int update_schedule(void)
{
	return(0);
}


void dump_mem(unsigned char *ptr, unsigned long bytes)
{
	unsigned long	i;
	int				j;
	char			ch;

	for (i=0; i<bytes; i++)
	{
		if (!(i%16)) 
			printf("\n%x: ", i+(unsigned long)ptr);

        ch=ptr[i];
		printf("%x ", ch);
	}
	printf("\n");
}