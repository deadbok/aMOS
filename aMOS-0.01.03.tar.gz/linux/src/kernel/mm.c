/*		mm.c

		Memory Managment

	History:
		Version 0.02.01	08 Oct 2000		19:09		ObliVion
		Simplified the whole damn thing, as this only used by the kernel.

		Version 0.01.01	03 July 2000	22:20		ObliVion
		Initial version.

		"Apartment of Computer Science"
*/

/*
	All these expressions, all these people, all their feelings
	All my hopes, all my dreams, all my hurts, all this light
	All energy being it god or evil, all this music, all this MUSIC
	I better make some music
*/
/*
	Aah now the moon is up
*/
/*
	"And if he doesn't kiss you, but it feels like you've been kissed"
*/
/*
	My name is Bondage, James Bondage.
*/
#include <string.h>
#include <i386/setup.h>
#include <kernel/mm.h>

/*
 *		int init_mm(void)
 *
 *		Initializes the Memory Manager
 *  
 */

int init_mm(void)
{
	return(0);
}

/*
 *		void *alloc_block(unsigned long size, unsigned long owner)
 *
 *		allocate "size" bytes of memory at "first fit"
 *  
 */

void *alloc_block(unsigned long size)
{
	return(NULL);
}

/*
 *		int dealloc_block(void *addr)
 *
 *		Deallocate block at "addr"
 *  
 */

int dealloc_block(void *addr)
{
	return(1);
}

unsigned long get_free_mem(void)
{
	return(0);
}

unsigned long get_used_mem(void)
{
	return(0);
}
