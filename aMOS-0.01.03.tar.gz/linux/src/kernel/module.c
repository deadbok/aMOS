/*		module.h

		The header for the dynamic module loader

	History:

		Version 0.01.00	04 Okt 2000	09:06		ObliVion
		Initial version.
*/

#include <string.h>
#include <kernel/module.h>

int mount_module(struct module_info *mip)
{
  return(0);
}

	    
