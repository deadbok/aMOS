/*		schedule.c

		The scheduler

	History:

		Version 0.01.00	6 Okt 2000	00:35		ObliVion
		Initial version.
*/
#include <stdio.h>
#include <i386/setup.h>
#include <kernel/schedule.h>
#include <kernel/mailbox.h>

void schedule(int signum);

char	in_handler = 0;

int init_sched(void)
{
	printf("Starting scheduler...\n");
	
	install_sched_func(schedule);
	return(0);
}

void schedule(int signum)
{
	if (!in_handler)
	{
		in_handler=1;
		if (message_dispatch())
			printf("Error dispatching messages!\n");

		in_handler=0;
	}
	
/*	return(0);*/
}