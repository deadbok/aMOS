/*		printf.c

		Implementation of the printf function

	History:

		Version 0.01	02 July 2000	16:53		ObliVion
		Initial version.
*/

#include <stdio.h>
#include <string.h>
#include <i386/video.h>
#include <kernel/video.h>
#include <kernel/mailbox.h>
#include <kernel/mm.h>

struct message	str_msg = {NULL, VMSG_STRING, 0, NULL};
struct message	ch_msg = {NULL, VMSG_CHAR, 0, NULL};

void	int_to_str(int i, char *str, int base);
int		print(const char *format, va_list va);

int printf(const char *format,...)
{
    va_list         va;

    va_start(va, format);
	return(print(format, va));
}

int print(const char *format, va_list va)
{

	unsigned long	i = 0;
	int				arg_processed = 0;
	char			*str_ptr;
	char			fixed_str_ptr[200];
	int				int_parm;

	while(*format)
	{
		if ((*format)=='%')
		{
			format++;
			while(!arg_processed)
			{
				switch(*format)
				{
					case 'd':	int_parm=va_arg(va, int);
								
								int_to_str(int_parm, fixed_str_ptr, 10);

								for (i=0; fixed_str_ptr[i]>0; i++)
									vid_putch(fixed_str_ptr[i]);

								arg_processed=1;
								format++;
								i=0;
								break;

					case 's':	str_ptr=va_arg(va, char *);

								str_msg.type=VMSG_STRING;
								str_msg.data_size=strlen(str_ptr);
								memcpy(str_msg.data, str_ptr, str_msg.data_size);
																
								send("video", &str_msg);

/*								for (i=0; str_ptr[i]>0; i++)
									vid_putch(str_ptr[i]);*/

								arg_processed=1;
								format++;
								i=0;
								break;

					case 'x':	int_parm=va_arg(va, int);
								
								fixed_str_ptr[0]='0';
								fixed_str_ptr[1]='x';

								int_to_str(int_parm, &fixed_str_ptr[2], 0x10);

								for (i=0; fixed_str_ptr[i]>0; i++)
									vid_putch(fixed_str_ptr[i]);

								arg_processed=1;
								format++;
								i=0;
								break;

					default: 	arg_processed=1;
								format++;
								break;
				}
			}
			arg_processed=0;
		}
		else
		{
			ch_msg.type=VMSG_CHAR;
			memcpy(ch_msg.data, format, 1);
			ch_msg.data="c";
			send("video", &ch_msg);
				
			format++;
		}
	}

    return 0;
}

/*
 *		void int_to_str(int i, char *str, int base)
 *		Converts an int to a string by of "base"
 *  
 *  
 *  	i:	roadrunner
 */

void int_to_str(int i, char *str, int base)
{
	int				temp_int;
	char			temp_str[200];
	unsigned long	j=0, k=0;
	unsigned long	end=0;

	if (i==0)
	{
		str[0]='0';
		str[1]='\0';
	}
	else
	{
		while (i>0)
		{
			temp_int=i%base;

			if (temp_int<10)
				temp_str[end++]=temp_int+'0';
			else
				temp_str[end++]=temp_int-10+'a';
		
			i/=base;
		}
	
		/*	The string resulting from the previous processing is 
			reversed so we fix that... */
		j=end;
		while (j>0)
		    str[k++]=temp_str[--j];

		str[k]='\0';
	}
}