/*		intsys.c

		The interrupt sub-system of the kernel (nothing cool yet)

	History:
		Version 0.01.02	16 Jul	2001	00:02		ObliVion
		Fixed up some bugs when sending EOI

		Version 0.01.01	06 Oct	2000	00:37		ObliVion
		Got it to work!

		Version 0.01.00	01 july 2000	21:18		ObliVion
		Initial version.
*/
#include <string.h>
#include <stdio.h>
#include <i386/setup.h>
#include <i386/intsys.h>
#include <i386/ports.h>
#include <i386/pic.h>

isr_func_t		intlist[MAX_INTS];

int init_intr(void)
{
	unsigned int	i;
		
	printf("Initializing interrupt system...\n");

	for (i=0; i<MAX_INTS; i++) /*	memset(intlist, handle_int, MAX_INTS);*/
		intlist[i]=NULL;

	return(0);
}

void handle_int(unsigned long intr)
{
	if (!intlist[intr])
		printf(" - unhandled Int %x - ", (unsigned int)intr);
	else
		(*(intlist[intr]))();
	
	if ((intr>=0x20) && (intr<0x28))
		outb(M_PIC, (intr-0x20)+EOI);

	if ((intr>=0x28) && (intr<0x30))
	{
		outb(S_PIC, (intr-0x20)+EOI);
		outb(M_PIC, 0x02+EOI);
	}
}

void install_isr(int intr, isr_func_t isr)
{
	if (intr<MAX_INTS)
	{
		intlist[intr]=isr;
	}
}

