/*		setup.c

		Architecture setup

	History:
		Version 0.01.01	06 Oct	2000	00:39		ObliVion
		Added function to install the scheduler interrupt.

		Version 0.01.00	16 Sep	2000	23:10		ObliVion
		Initial version.
*/
#include <stdio.h>
#include <i386/setup.h>
#include <i386/video.h>
#include <i386/pic.h>
#include <i386/pit.h>
#include <i386/tss.h>
#include <i386/ports.h>
#include <i386/intsys.h>
#include <kernel/version.h>

#ifdef DEBUG
	#include <i386/debug.h>
#endif

int	arch_setup(void)
{
	vid_init();
	create_vid_mailbox();

	init_pit();
		
	printf("\naMOS V.%s %s\n", STRING_VERSION, BUILD_ARCH);
	printf("Build %s %s by %s on %s\n\n", COMPILE_DATE, COMPILE_TIME, COMPILE_BY, COMPILE_HOST);
	
	printf("---------- arch_setup ----------\n"); 
	init_pic();
	init_intr();

	int_enable();

	init_tss();

	return(0);
}

int install_sched_func(void *func)
{
	install_isr(0x20, func);
	unmask_irq(0);

	return(0);
}

void dump_mem(unsigned char *ptr, unsigned long bytes)
{
	unsigned long	i;
	char			ch;

	for (i=0; i<bytes; i++)
	{
		if (!(i%16)) 
			printf("\n%x: ", i+(unsigned long)ptr);

        ch=ptr[i];
		printf("%x ", ch);
	}
	printf("\n");
}

