/*		int.h

		The interrupt sub-system of the kernel (nothing cool yet)

	History:

		Version 0.01.00	01 july 2000	21:18		ObliVion
		Initial version.
*/
#ifndef _KERNEL_INTSYS_H_
#define _KERNEL_INTSYS_H_

typedef void (*isr_func_t)(void);

extern int	init_intr(void);
extern void handle_int(unsigned long intr);
extern void install_isr(int intr, isr_func_t isr);

#define int_enable()		__asm__ __volatile__ ("sti" ::: "memory")
#define int_disable()		__asm__ __volatile__ ("cli" ::: "memory")

#endif

