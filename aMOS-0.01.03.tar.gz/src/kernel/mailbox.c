/*		mailbox.c

		The mailbox code for comunication with (and within) the micro-kernel

	History:
		Version 0.01.01	16 Jul 2000	00:59		ObliVion
		Fixed a bug in the send function. Now local copies of message and data are used

		Version 0.01.01	10 Sep 2000	13:15		ObliVion
		Initial version.
*/

#include <stdio.h>
#include <string.h>
#include <i386/setup.h>
#include <kernel/video.h>
#include <kernel/mailbox.h>

#ifdef DEBUG
	#include <i386/debug.h>
#endif

int dispatch_ok = 1;

struct mailbox *get_mb(mailbox_id_type id);

unsigned int		free_mailbox_id = 1;
struct list_node	*mailboxes = NULL;
struct list_node	*last_mailbox = NULL;

mailbox_id_type create_mb(rcv_func_t reciever)
{
	struct list_node		*mb_node = NULL;
	struct mailbox		*mb = NULL;

	dispatch_ok = 0;
		
#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:create_mb\n");
#endif

	mb=(struct mailbox *)malloc(sizeof(struct mailbox));
	
	mb->id = free_mailbox_id;
		
	free_mailbox_id++;
		
	mb->messages = NULL;
	mb->reciever = reciever;

	mb_node = new_node();
	(struct mailbox *)mb_node->data = mb;

	mailboxes = add_node(mailboxes, mb_node);

	if (!mailboxes)
	{
#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:couldn't add mailbox to list\n");
#endif

		dispatch_ok = 1;
		return(MAILBOX_CANT_ADD);
	}
				
#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:create_mb created with id %d and node address 0x%x\n", mb->id, (unsigned int)mb_node);
#endif

	dispatch_ok = 1;

	return(mb->id);
}

struct mailbox *get_mb(mailbox_id_type id)
{
	struct list_node		*mb_node = mailboxes;
	struct mailbox		*mb = NULL;

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:get_mb\n");
#endif

	if (!mb_node)
	{
#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:no mailboxes\n");
#endif
    
		return(NULL);
	}
				
	while (mb_node)
	{
        mb = (struct mailbox *)mb_node->data;    
    
#ifdef DEBUG    
	debug_printf("DEBUG: mailbox.c:mailbox %d exists\n", mb->id);    
#endif

        if (mb->id==id)
		{
            return(mb);
		}
		mb_node=mb_node->next;
	}
#ifdef DEBUG    
	debug_printf("DEBUG: mailbox.c:no mailbox found\n");    
#endif

	return(NULL);
}

int send(mailbox_id_type id, struct msg *message)
{
	struct mailbox		*mb = NULL ;
	struct list_node		*msg_node = NULL;
	struct msg			*temp_msg;
		
#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:send\n");
#endif

	dispatch_ok = 0;		

	if (!message)
	{
		dispatch_ok = 1;

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:send Empty message\n");
#endif
								
		return(MAILBOX_EMPTY_MESSAGE);
	}

	mb=get_mb(id);
		
	if (!mb)
	{
		dispatch_ok = 1;				

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:Mailbox doesn't exist\n");
#endif
				
		return(MAILBOX_DONT_EXIST);
	}

	msg_node = new_node();

	if (!msg_node)
	{
		dispatch_ok = 1;				

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:Cant allocate node\n");
#endif
				
		return(MAILBOX_DONT_EXIST);
	}


#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:Node 0x%x\n", msg_node);
#endif

	/*shouln't need to do this*/
	msg_node->next=NULL;

/*	This is against the description of the Message System
	but it is used until a better solution is possible*/
	temp_msg = (struct msg *)malloc(sizeof(struct msg));
	memcpy(temp_msg, message, sizeof(struct msg));

	temp_msg->data = (void *)malloc(message->data_size);
	memcpy(temp_msg->data, message->data, message->data_size);
				
	msg_node->data = temp_msg;

	mb->messages = add_node(mb->messages, msg_node);

	if (!mb->messages)
	{
#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:could not add message\n", msg_node->data);
#endif
            dispatch_ok = 1;		
			return(MAILBOX_DONT_EXIST);
	}

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:send message 0x%x\n", msg_node->data);
#endif

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:send First char of message 0x%x\n", *(char *)((struct msg *)(msg_node->data))->data);
#endif
	
	dispatch_ok = 1;		
	return(MAILBOX_OK);
}

int message_dispatch(void)
{
	struct mailbox		*mb;
	struct list_node		*msg_node;
	struct msg			*message;

	if ((!dispatch_ok) || (!mailboxes))
		return(0);

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:message_dispatch\n");
#endif

	mb = (struct mailbox *)mailboxes->data;		

	if (mb->messages)
	{
		msg_node = (struct list_node *)mb->messages;
					
		message = (struct msg *)msg_node->data;

#ifdef DEBUG
	debug_printf("DEBUG: mailbox.c:calling reciever, 0x%x with message 0x%x\n", mb->reciever, message);
#endif
		mb->reciever(message);

		mb->messages = msg_node->next;
		free(msg_node->data);
		free(msg_node);
	}

	return(0);
}

