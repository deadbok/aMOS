/*		schedule.c

		The scheduler

	History:

		Version 0.01.00	6 Okt 2000	00:35		ObliVion
		Initial version.
*/
#include <stdio.h>
#include <i386/setup.h>
#include <kernel/mailbox.h>
#include <kernel/schedule.h>

#ifdef DEBUG
	#include <i386/debug.h>
#endif

int in_scheduler = 0;

void schedule(void);

int init_sched(void)
{
#ifdef DEBUG		
	debug_printf("DEBUG: schedule.c:init_sched %d\n", in_scheduler);
#endif
	printf("Starting scheduler...\n");
	
	install_sched_func(schedule);
	return(0);
}

void schedule(void)
{
#ifdef DEBUG		
	debug_printf("DEBUG: schedule.c:schedule %d\n", in_scheduler);
#endif

	if (in_scheduler)
		return;

	in_scheduler=1;

	if (message_dispatch())
		printf("Error dispatching messages!\n");
				
	in_scheduler=0;
}
