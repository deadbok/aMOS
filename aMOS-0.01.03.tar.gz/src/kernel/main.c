/*		main.c

		The main C code for the aMOS kernel

	History:
		Version 0.01.10	10 Sep 2000	14:07		ObliVion
		Initial version.

		Version 0.01.01	17 May 2000	17:45		ObliVion
		Initial version.
*/

/*
	They keep showing this comercial on the telly
	"this dream feels like ours"
	It's one of those comercials that depends on "harmony"
	The mood is wonderfully expressed
	But the point is...
	There is this girl
	And there is this 1 second shot of her face
	As she wakes up her boyfriend
	She has the most beautiful expression in her face
	I've never seen anything quite as beautiful
	In a comercial
	And all it does my dear sunflower
	Is push the knife in a little bit more
	'Cos you were that beautiful most of the time
	That's one of the reasons I still love you
	When you've seen what you think is perfection
	You don't just let it slip away
*/

#include <stdio.h>
#include <stddef.h>
#include <kernel/mm.h>
#include <i386/setup.h>
#include <kernel/video.h>
#include <kernel/mailbox.h>
#include <kernel/schedule.h>
#include <i386/debug.h>

/*#define DEBUG*/

int main(void)
{
	init_debug();

	if (init_mm())
		return(1);

	if (arch_setup())
		return(1);

	printf("------------- main -------------\n");

	if (init_sched())
		return(1);

	printf("------------- test -------------\n");

	printf("Free kernel mem: %d bytes\nUsed kernel mem: %d bytes\n", (int)get_free_mem(), (int)get_used_mem());

#ifdef DEBUG
	debug_printf("DEBUG: main.c:main This is where the processor goes haywire in nothings\n");
#endif		
	for (;;) {}
		
	return(0);
}

