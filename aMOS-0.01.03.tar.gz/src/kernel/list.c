/*		list.c

		Source file for the aMOS mikro-kernel linked list
		implementation

	History:
		Version 0.01.01	07 Apr 2001	19:55		ObliVion
		Initial version.

	-	In every data object there should be pointers to function which
		new and delete the data. These functions are then supplied bu the
		code usihng the linked list. Here we just call them blindly hoping
		that they will do the right thing.
*/


#include <string.h>
#include <kernel/list.h>

#ifdef DEBUG
	#include <i386/debug.h>
#endif

struct list_node	*new_node(void)
{
	struct list_node	*temp_node;

#ifdef DEBUG		
	debug_printf("DEBUG: list.c:new_node\n");
#endif
				
	temp_node=(struct list_node *)malloc(sizeof(struct list_node));

	temp_node->data=NULL;
    temp_node->next=NULL;

#ifdef DEBUG		
	debug_printf("DEBUG: list.c:new_node returns 0x%x\n", (unsigned int)temp_node);
#endif
				
	return(temp_node);
}

struct list_node *add_node(struct list_node *root, struct list_node *new_node)
{
	struct list_node		*temp_node;
	if (!new_node)
	{
#ifdef DEBUG		
	debug_printf("DEBUG: list.c:add_node NULL node no action taken\n");
#endif
						
		return(root);
	}

	new_node->next = NULL;

	if (root)
	{
		temp_node = root;

		while(temp_node->next)
			temp_node = temp_node->next;

		temp_node->next = new_node;
    	}
    	else
		root = new_node;

#ifdef DEBUG		
	debug_printf("DEBUG: list.c:add_node added 0x%x bew root 0x%x root next 0x%x\n", (unsigned int)new_node, (unsigned int)root, (unsigned int)root->next);
#endif

	return(root);
}

int	destroy_list(struct list_node *root)
{
	if (root->next)
		destroy_list(root->next);

	free(root);
	
	return(LIST_OK);
}

