/*		bform.c

		Brute formats (direct BIOS Int) a disk 

	History:

		Version 0.01	13 Apr 2000	08:41		ObliVion
		Initial version.

*/

main (int argc, char **argv)
{
}
