/*		fd.c

		Standard floppy disk driver

	History:

		Version 0.01	17 May 2000	16:37		ObliVion
		Initial version.
*/

