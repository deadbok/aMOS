/*		fd.h

		Header for the standard floppy disk driver

	History:

		Version 0.01	17 May 2000	16:38		ObliVion
		Initial version.
*/

