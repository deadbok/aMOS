#ifndef _KERNEL_VERSION_H_
#define _KERNEL_VERSION_H_
#define STRING_VERSION "0.01.05"
#define BUILD_ARCH "i386"
#define COMPILE_DATE "08/04/2000"
#define COMPILE_TIME "19:18:41"
#define COMPILE_BY "root"
#define COMPILE_HOST "aMOS"
#define COMPILER "gcc version egcs-2.91.66 19990314/Linux (egcs-1.1.2 release)"
#endif
